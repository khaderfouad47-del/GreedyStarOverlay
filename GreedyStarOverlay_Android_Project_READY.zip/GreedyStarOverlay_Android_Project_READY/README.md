# GreedyStarOverlay_Android_Project_READY

Android Native starter for a floating Greedy Star screen analyzer.

## What is included
- Floating overlay button/panel.
- MediaProjection permission flow for reading the game screen.
- Screenshot capture service.
- ML Kit OCR dependency for readable text such as round number/time/multipliers.
- Local history storage and heuristic probability analysis (frequency + transition/Markov weighting).
- No automatic betting/clicking.

## Important limitation
The food-wheel result is graphical, so OCR alone cannot identify the food icons. The next implementation step is image classification/template matching for the six food symbols using screenshots from the actual device. The predictor reports probabilities, not guaranteed outcomes.

## Build
Open in Android Studio or push to GitHub and build with Gradle/Actions. The project uses Android Gradle Plugin 8.5.2 and compileSdk 35.
