package com.greedystar.overlay;

import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.media.projection.MediaProjection;import android.media.projection.MediaProjectionManager;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

public class CaptureService extends Service {
    WindowManager wm; View overlay; MediaProjection projection; Analyzer analyzer=new Analyzer();
    public int onStartCommand(Intent in,int flags,int id){ if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("gs","Greedy Star",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(ch);startForeground(7,new Notification.Builder(this,"gs").setContentTitle("Greedy Star Overlay").setContentText("تحليل الشاشة يعمل").setSmallIcon(android.R.drawable.ic_menu_view).build());}
        if(Settings.canDrawOverlays(this)) showOverlay(); if(in!=null&&"START_CAPTURE".equals(in.getAction())){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);projection=m.getMediaProjection(in.getIntExtra("resultCode",0),(Intent)in.getParcelableExtra("data"));}
        return START_STICKY; }
    void showOverlay(){ if(overlay!=null)return; wm=(WindowManager)getSystemService(WINDOW_SERVICE); TextView v=new TextView(this);v.setText("★\nتحليل");v.setTextColor(0xffffffff);v.setTextSize(13);v.setGravity(17);v.setBackgroundResource(com.greedystar.overlay.R.drawable.round_button);v.setPadding(18,10,18,10);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; WindowManager.LayoutParams p=new WindowManager.LayoutParams(90,90,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; wm.addView(v,p);overlay=v;
        v.setOnClickListener(x->{Toast.makeText(this,"سيتم ربط التقاط النتائج والتعرف على الرموز في النسخة التالية. لا يوجد توقع مضمون.",Toast.LENGTH_LONG).show();}); }
    public IBinder onBind(Intent i){return null;} public void onDestroy(){if(overlay!=null)wm.removeView(overlay);super.onDestroy();}
}
