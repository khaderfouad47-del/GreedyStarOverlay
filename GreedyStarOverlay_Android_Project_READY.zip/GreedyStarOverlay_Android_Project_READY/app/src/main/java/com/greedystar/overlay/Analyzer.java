package com.greedystar.overlay;

import java.util.*;

public class Analyzer {
    public static class Prediction { public final String name; public final double score; Prediction(String n,double s){name=n;score=s;} }
    private final List<String> history = new ArrayList<>();
    private final Map<String,Integer> freq = new HashMap<>();
    private final Map<String,Map<String,Integer>> trans = new HashMap<>();
    public void add(String x){ if(x==null||x.isEmpty())return; if(!history.isEmpty()){String p=history.get(history.size()-1); trans.computeIfAbsent(p,k->new HashMap<>()).merge(x,1,Integer::sum);} history.add(x); freq.merge(x,1,Integer::sum); if(history.size()>200) history.remove(0); }
    public List<Prediction> predict(){
        if(freq.isEmpty()) return Collections.emptyList();
        Map<String,Double> s=new HashMap<>(); int n=history.size();
        for(Map.Entry<String,Integer> e:freq.entrySet()) s.put(e.getKey(), e.getValue()/(double)n);
        String last=history.get(history.size()-1); Map<String,Integer> t=trans.get(last);
        if(t!=null){int total=t.values().stream().mapToInt(i->i).sum(); for(Map.Entry<String,Integer> e:t.entrySet()) s.put(e.getKey(), s.getOrDefault(e.getKey(),0d)+0.60*e.getValue()/total);}
        List<Prediction> out=new ArrayList<>(); for(Map.Entry<String,Double> e:s.entrySet())out.add(new Prediction(e.getKey(),e.getValue()));
        out.sort((a,b)->Double.compare(b.score,a.score)); return out.subList(0,Math.min(3,out.size()));
    }
    public int size(){return history.size();}
}
