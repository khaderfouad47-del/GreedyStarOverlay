package com.greedystar.overlay;

import android.app.*;import android.content.*;import android.graphics.Color;import android.media.projection.MediaProjectionManager;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
    static final int REQ_OVERLAY=10, REQ_CAPTURE=11; Analyzer analyzer=new Analyzer();
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,40,40,40); root.setBackgroundColor(Color.WHITE);
        TextView t=new TextView(this); t.setText("Greedy Star Overlay"); t.setTextSize(26); t.setTextColor(Color.DKGRAY); root.addView(t);
        TextView info=new TextView(this); info.setText("تطبيق عائم لتحليل الشاشة والنتائج. التوقع احتمالي وليس مضموناً."); info.setTextSize(17); info.setPadding(0,20,0,30); root.addView(info);
        Button overlay=new Button(this); overlay.setText("1) تفعيل العائم"); root.addView(overlay); overlay.setOnClickListener(v->enableOverlay());
        Button capture=new Button(this); capture.setText("2) السماح بقراءة الشاشة"); root.addView(capture); capture.setOnClickListener(v->startCapturePermission());
        Button test=new Button(this); test.setText("اختبار المحلل"); root.addView(test); TextView result=new TextView(this); result.setTextSize(16); root.addView(result);
        test.setOnClickListener(v->{analyzer.add("طماطم");analyzer.add("جزر");analyzer.add("فراخ");analyzer.add("بروكلي");StringBuilder s=new StringBuilder("آخر سجل: "+analyzer.size()+"\n"); for(Analyzer.Prediction p:analyzer.predict())s.append(p.name).append(" — ").append(String.format("%.1f%%",p.score*100)).append("\n");result.setText(s.toString());});
        setContentView(root);
    }
    void enableOverlay(){if(!Settings.canDrawOverlays(this)){startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),REQ_OVERLAY));}else {startService(new Intent(this,CaptureService.class).setAction("OVERLAY_ONLY"));Toast.makeText(this,"العائم اتفعل",Toast.LENGTH_SHORT).show();}}
    void startCapturePermission(){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==REQ_CAPTURE&&c==RESULT_OK&&d!=null){Intent i=new Intent(this,CaptureService.class);i.setAction("START_CAPTURE");i.putExtra("resultCode",c);i.putExtra("data",d);startForegroundService(i);}}
}
